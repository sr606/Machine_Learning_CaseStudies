from typing import Dict, Any, List

SQL_TYPE_MAP = {
    "INTEGER": "INTEGER",
    "FLOAT": "NUMERIC(38,10)",
    "BOOLEAN": "BOOLEAN",
    "TIMESTAMP": "TIMESTAMP",
    "TEXT": "TEXT",
}

def _fmt_col(name: str, col_meta: Dict[str, Any]) -> str:
    sql_type = SQL_TYPE_MAP.get(col_meta.get("type", "TEXT"), "TEXT")
    return f'  "{name}" {sql_type}'

def generate_ddl(model: Dict[str, Any]) -> str:
    """
    Generate PostgreSQL-compatible DDL for 3NF: PKs and FKs from model.
    """
    tables = model.get("tables", {})
    fks = model.get("foreign_keys", [])

    ddl_lines: List[str] = []
    # Table DDL
    for t_name, t_meta in tables.items():
        cols_lines = []
        for c_name, c_meta in t_meta.get("columns", {}).items():
            cols_lines.append(_fmt_col(c_name, c_meta))

        pk = t_meta.get("primary_key")
        if pk:
            cols_lines.append(f'  PRIMARY KEY ("{pk}")')

        ddl_lines.append(f'CREATE TABLE "{t_name}" (\n' + ",\n".join(cols_lines) + "\n);\n")

    # Foreign keys
    for fk in fks:
        ddl_lines.append(
            f'ALTER TABLE "{fk["table"]}" '
            f'ADD CONSTRAINT "fk_{fk["table"]}_{fk["column"]}_{fk["ref_table"]}" '
            f'FOREIGN KEY ("{fk["column"]}") REFERENCES "{fk["ref_table"]}" ("{fk["ref_column"]}");\n'
        )

    # Helpful indexes for FKs (optional)
    for fk in fks:
        ddl_lines.append(
            f'CREATE INDEX "ix_{fk["table"]}_{fk["column"]}" ON "{fk["table"]}" ("{fk["column"]}");\n'
        )

    return "\n".join(ddl_lines).strip()

def save_ddl(sql: str, out_path: str):
    with open(out_path, "w", encoding="utf-8") as fh:
        fh.write(sql + "\n")
