import argparse
import os
import json
import itertools
from collections import defaultdict, Counter
import pandas as pd
import numpy as np

# -----------------------------
# Utilities
# -----------------------------
def powerset(iterable, start_size=1, end_size=None):
    xs = list(iterable)
    n = len(xs)
    if end_size is None:
        end_size = n
    for r in range(start_size, end_size + 1):
        for comb in itertools.combinations(xs, r):
            yield frozenset(comb)

def series_is_constant_given_groups(df, lhs_cols, rhs_col):
    """
    Check FD: LHS -> RHS by verifying RHS is constant within each LHS equivalence class.
    """
    if not lhs_cols:
        # Empty LHS: only holds if rhs has single value overall
        return df[rhs_col].nunique(dropna=False) <= 1
    grouped = df.groupby(list(lhs_cols), dropna=False)[rhs_col].nunique(dropna=False)
    return (grouped <= 1).all()

def unique_key(df, cols):
    """
    Check if cols constitute a key (unique rows after dropping NaNs in key).
    """
    if not cols:
        return False
    return df[list(cols)].drop_duplicates().shape[0] == df.shape[0]

def infer_sql_type(series):
    if pd.api.types.is_integer_dtype(series):
        return "INTEGER"
    if pd.api.types.is_float_dtype(series):
        return "DECIMAL(12,2)"
    # Try timestamp/date detection heuristics
    sample = series.dropna().astype(str).head(50)
    parseable = 0
    for s in sample:
        try:
            pd.to_datetime(s)
            parseable += 1
        except Exception:
            pass
    if parseable / max(1, len(sample)) > 0.8:
        return "TIMESTAMP"
    return "TEXT"

# -----------------------------
# TANE-style FD discovery (level-wise)
# -----------------------------
def tane_fd_discovery(df, max_cols=None, support_tolerance=0.0):
    """
    Discover functional dependencies using TANE-style level-wise search.
    - df: pandas DataFrame
    - max_cols: limit number of columns to consider (for very wide tables)
    - support_tolerance: allow small violations (fraction), default exact
    Returns list of (lhs_set, rhs_attr) where FD holds.
    """
    cols = list(df.columns)
    if max_cols is not None and len(cols) > max_cols:
        cols = cols[:max_cols]

    # Level-wise: start with singletons for LHS
    fds = []
    # Precompute partitions for pruning: equivalence classes per attribute set
    # For simplicity, compute on the fly (sufficient for moderate sizes).
    # Level loop
    for k in range(0, len(cols)):  # LHS size from 0..len(cols)-1
        for lhs in itertools.combinations(cols, k):
            lhs_set = frozenset(lhs)
            # Candidate RHS are attributes not in LHS
            for rhs in cols:
                if rhs in lhs_set:
                    continue
                # Check FD with tolerance if specified
                if support_tolerance == 0.0:
                    holds = series_is_constant_given_groups(df, lhs_set, rhs)
                else:
                    # Tolerant check: proportion of groups with nunique==1
                    if not lhs_set:
                        holds = df[rhs].nunique(dropna=False) <= 1
                    else:
                        grouped = df.groupby(list(lhs_set), dropna=False)[rhs].nunique(dropna=False)
                        ok = (grouped == 1).sum()
                        holds = ok / len(grouped) >= (1.0 - support_tolerance)
                if holds:
                    fds.append((lhs_set, rhs))
    return fds

# -----------------------------
# Minimal cover of FDs
# -----------------------------
def minimal_cover(fds):
    """
    Convert to minimal cover:
    1) Decompose RHS: each FD has 1 attribute on RHS
    2) Remove extraneous attributes from LHS
    3) Remove redundant FDs
    """
    # 1) ensure RHS is single
    single_rhs = [(X, A) for (X, A) in fds]

    # 2) remove extraneous from LHS (test each attr)
    def closure(attrs, fds_set):
        # Compute attribute closure under current FD set
        result = set(attrs)
        changed = True
        while changed:
            changed = False
            for X, A in fds_set:
                if X.issubset(result) and A not in result:
                    result.add(A)
                    changed = True
        return result

    pruned = []
    for (X, A) in single_rhs:
        X = set(X)
        changed = True
        while changed:
            changed = False
            for x in list(X):
                test_X = frozenset(X - {x})
                fds_except = [(Y, B) for (Y, B) in pruned] + [(frozenset(X), A)]
                # Temporarily remove current FD, test implication with smaller LHS
                temp = [(Y, B) for (Y, B) in pruned] + [(test_X, A)]
                if A in closure(test_X, temp):
                    X.remove(x)
                    changed = True
        pruned.append((frozenset(X), A))

    # 3) remove redundant FDs
    final = []
    for i, (X, A) in enumerate(pruned):
        others = pruned[:i] + pruned[i+1:]
        if A in closure(X, others):
            continue
        final.append((X, A))
    return final

# -----------------------------
# Bernstein’s 3NF synthesis
# -----------------------------
def bernstein_synthesis(min_cover):
    """
    Synthesize relations:
    - For each distinct LHS, create a relation with attributes LHS ∪ RHSs.
    - Merge relations with identical LHS.
    - If needed, add a relation for a candidate key that covers all attributes (to ensure lossless join).
    """
    by_lhs = defaultdict(set)
    attrs_all = set()
    for X, A in min_cover:
        by_lhs[X].add(A)
        attrs_all |= set(X)
        attrs_all.add(A)

    relations = []
    for X, Ys in by_lhs.items():
        rel_attrs = set(X) | set(Ys)
        relations.append({"key": set(X), "attrs": rel_attrs})

    # Find a candidate key that determines all attributes
    # Simple heuristic: smallest LHS whose closure covers attrs_all
    def closure(X, fds_set):
        result = set(X)
        changed = True
        while changed:
            changed = False
            for Y, B in fds_set:
                if Y.issubset(result) and B not in result:
                    result.add(B)
                    changed = True
        return result

    # Attempt keys among union of LHSs
    candidates = sorted(list(set().union(*[set(X) for X in by_lhs.keys()])))

    found_key = None
    for r in range(1, len(candidates)+1):
        for comb in itertools.combinations(candidates, r):
            if closure(set(comb), min_cover) >= attrs_all:
                found_key = set(comb)
                break
        if found_key:
            break
    if found_key and not any(found_key.issubset(rel["attrs"]) for rel in relations):
        relations.append({"key": found_key, "attrs": found_key})  # add key relation minimally

    # Remove contained relations (if attrs subset of another relation)
    pruned = []
    for i, ri in enumerate(relations):
        contained = False
        for j, rj in enumerate(relations):
            if i == j:
                continue
            if ri["attrs"].issubset(rj["attrs"]):
                contained = True
                break
        if not contained:
            pruned.append(ri)

    return pruned

# -----------------------------
# Materialization: project CSV into normalized relations
# -----------------------------
def materialize_relations(df, relations):
    """
    For each synthesized relation, project the original dataframe onto the relation's attributes
    and deduplicate by the key.
    """
    frames = []
    for idx, rel in enumerate(relations):
        cols = [c for c in rel["attrs"] if c in df.columns]
        if not cols:
            continue
        key_cols = [c for c in rel["key"] if c in cols]
        proj = df[cols].drop_duplicates(subset=key_cols if key_cols else None)
        frames.append({"name": f"R_{idx+1}", "key": key_cols, "attrs": cols, "df": proj})
    return frames

# -----------------------------
# PK/FK heuristics
# -----------------------------
def detect_primary_keys(frames):
    """
    Mark a frame's key columns as PK if they uniquely identify rows.
    If no key given or non-unique, try to infer smallest unique set.
    """
    for f in frames:
        df = f["df"]
        key = f["key"]
        if key and unique_key(df, key):
            f["pk"] = key
        else:
            # Try to infer minimal unique key
            cols = f["attrs"]
            found = None
            for r in range(1, min(4, len(cols))+1):
                for comb in itertools.combinations(cols, r):
                    if unique_key(df, comb):
                        found = list(comb)
                        break
                if found:
                    break
            f["pk"] = found if found else key

def infer_foreign_keys(frames):
    """
    Heuristic FK inference: if a non-PK column set in one frame matches the PK of another frame
    and values are contained, mark FK.
    """
    fks = []
    # Build quick lookup of PK domains
    pk_domains = {}
    for f in frames:
        if f.get("pk"):
            pk_domains[(f["name"], tuple(f["pk"]))] = set(map(tuple, f["df"][f["pk"]].dropna().values.tolist()))

    for f in frames:
        df = f["df"]
        for (ref_name, ref_pk) in pk_domains.keys():
            ref_set = pk_domains[(ref_name, ref_pk)]
            # If this frame contains all columns of the ref_pk
            if all(col in df.columns for col in ref_pk):
                vals = set(map(tuple, df[list(ref_pk)].dropna().values.tolist()))
                if vals and vals.issubset(ref_set) and f["name"] != ref_name:
                    fks.append({
                        "table": f["name"],
                        "columns": list(ref_pk),
                        "ref_table": ref_name,
                        "ref_columns": list(ref_pk)
                    })
    return fks

# -----------------------------
# SQL & ERD generation
# -----------------------------
def generate_sql(frames, fks):
    stmts = []
    for f in frames:
        cols = []
        for c in f["attrs"]:
            t = infer_sql_type(f["df"][c])
            cols.append(f"    {c} {t}")
        # PK
        if f.get("pk"):
            cols.append(f"    PRIMARY KEY ({', '.join(f['pk'])})")
        stmts.append(f"CREATE TABLE {f['name']} (\n" + ",\n".join(cols) + "\n);")
    # FKs
    for fk in fks:
        stmts.append(
            f"ALTER TABLE {fk['table']} ADD FOREIGN KEY ({', '.join(fk['columns'])}) "
            f"REFERENCES {fk['ref_table']}({', '.join(fk['ref_columns'])});"
        )
    return "\n\n".join(stmts)

def generate_erd(frames, fks):
    lines = ["digraph ERD {", "  rankdir=LR;"]
    for f in frames:
        cols = "\\n".join(f["attrs"])
        lines.append(f'  {f["name"]} [shape=record, label="{{{f["name"]}|{cols}}}"];')
    for fk in fks:
        label = ",".join(fk["columns"])
        lines.append(f'  {fk["table"]} -> {fk["ref_table"]} [label="{label}"];')
    lines.append("}")
    return "\n".join(lines)
def analyze_and_normalize_generic(df: pd.DataFrame, tolerance: float = 0.0) -> dict:
    fds = tane_fd_discovery(df, support_tolerance=tolerance)
    min_cov = minimal_cover(fds)
    relations = bernstein_synthesis(min_cov)
    frames = materialize_relations(df, relations)
    normalized_model = {f["name"]: f["df"] for f in frames}
    return {
        "normalized_model": normalized_model,
        "relations": relations,
        "fds": min_cov,
        "frames": frames
    }
# -----------------------------
# Main CLI
# -----------------------------
def main():
    parser = argparse.ArgumentParser(description="Domain-agnostic 3NF synthesis using TANE-style FD discovery")
    parser.add_argument("--input", required=True, help="Input CSV file")
    parser.add_argument("--out", required=True, help="Output directory")
    parser.add_argument("--max-cols", type=int, default=None, help="Limit number of columns considered")
    parser.add_argument("--tolerance", type=float, default=0.0, help="FD tolerance (0.0 exact, e.g., 0.05 allows 5% violations)")
    args = parser.parse_args()

    os.makedirs(args.out, exist_ok=True)
    df = pd.read_csv(args.input)

    # FD discovery
    fds = tane_fd_discovery(df, max_cols=args.max_cols, support_tolerance=args.tolerance)

    # Minimal cover
    min_cov = minimal_cover(fds)

    # Synthesize 3NF relations
    relations = bernstein_synthesis(min_cov)

    # Materialize projected tables
    frames = materialize_relations(df, relations)

    # PK/FK inference
    detect_primary_keys(frames)
    fks = infer_foreign_keys(frames)

    # Write outputs
    with open(os.path.join(args.out, "fds.json"), "w", encoding="utf-8") as fh:
        json.dump([{"lhs": list(X), "rhs": A} for (X, A) in min_cov], fh, indent=2)

    with open(os.path.join(args.out, "relations.json"), "w", encoding="utf-8") as fh:
        json.dump([{"key": list(r["key"]), "attrs": list(r["attrs"])} for r in relations], fh, indent=2)

    # Save CSVs
    for i, f in enumerate(frames, 1):
        f["df"].to_csv(os.path.join(args.out, f"{f['name']}.csv"), index=False)

    # SQL & ERD
    sql = generate_sql(frames, fks)
    with open(os.path.join(args.out, "schema.sql"), "w", encoding="utf-8") as fh:
        fh.write(sql)

    erd = generate_erd(frames, fks)
    with open(os.path.join(args.out, "erd.dot"), "w", encoding="utf-8") as fh:
        fh.write(erd)

    print(f"Discovered {len(min_cov)} minimal FDs")
    print(f"Synthesized {len(frames)} relations")
    print("Outputs written to:", args.out)

if __name__ == "__main__":
    main()
