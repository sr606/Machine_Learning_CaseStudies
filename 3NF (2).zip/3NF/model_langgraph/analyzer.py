import os
import pandas as pd
import numpy as np
import json
from typing import Dict, Tuple, Any, List, Set, Optional

try:
    from transformers import pipeline
except Exception:
    pipeline = None

# -----------------------------
# Profiling / Type Inference
# -----------------------------
def infer_column_type(series: pd.Series) -> str:
    if pd.api.types.is_integer_dtype(series.dropna()):
        return 'INTEGER'
    if pd.api.types.is_float_dtype(series.dropna()):
        return 'FLOAT'
    if pd.api.types.is_bool_dtype(series.dropna()):
        return 'BOOLEAN'
    if pd.api.types.is_datetime64_any_dtype(series.dropna()):
        return 'TIMESTAMP'
    return 'TEXT'


def detect_primary_keys(tables: Dict[str, pd.DataFrame]) -> Dict[str, str]:
    pks = {}
    for name, df in tables.items():
        candidates = []
        for col in df.columns:
            s = df[col]
            unique_frac = s.dropna().nunique() / max(1, len(s))
            if col.lower() == 'id' or col.lower().endswith('_id'):
                candidates.append((col, unique_frac))
            if unique_frac > 0.9 and s.dropna().dtype != object:
                candidates.append((col, unique_frac))
        if candidates:
            candidates.sort(key=lambda x: -x[1])
            pks[name] = candidates[0][0]
        else:
            pks[name] = None
    return pks


def detect_foreign_keys(tables: Dict[str, pd.DataFrame], pks: Dict[str, str]) -> Dict[Tuple[str, str], Tuple[str, str]]:
    fks = {}
    pk_values = {}
    for t, pk in pks.items():
        if pk and pk in tables[t].columns:
            pk_values[t] = set(tables[t][pk].dropna().unique())

    for t, df in tables.items():
        for col in df.columns:
            if pks.get(t) == col:
                continue
            vals = set(df[col].dropna().unique())
            if not vals:
                continue
            for ref_table, ref_vals in pk_values.items():
                if ref_table == t:
                    continue
                common = vals.intersection(ref_vals)
                if len(common) / max(1, len(vals)) > 0.5:
                    fks[(t, col)] = (ref_table, pks[ref_table])
                    break
    return fks


def generate_column_descriptions(tables: Dict[str, pd.DataFrame]) -> Dict[str, Dict[str, str]]:
    desc = {}
    use_llm = False
    gen = None

    if pipeline is not None and os.getenv('LOCAL_LLM_MODEL'):
        try:
            gen = pipeline('text-generation', model=os.getenv('LOCAL_LLM_MODEL'))
            use_llm = True
        except Exception as e:
            print("LLM pipeline init failed:", e)
            use_llm = False

    for t, df in tables.items():
        desc[t] = {}
        for col in df.columns:
            sample = df[col].dropna().astype(str).head(5).tolist()
            simple = f"Column `{col}` of table `{t}`. Type guess: {infer_column_type(df[col])}. Samples: {sample}"

            if use_llm and gen is not None:
                prompt = f"Provide a concise, single-sentence description for this column: {simple}"
                try:
                    out = gen(prompt, max_new_tokens=50)  # safer arg
                    if isinstance(out, list) and "generated_text" in out[0]:
                        desc_text = out[0]["generated_text"].strip().split("\n")[0]
                    elif isinstance(out, list) and "text" in out[0]:
                        desc_text = out[0]["text"].strip().split("\n")[0]
                    else:
                        desc_text = simple
                except Exception as e:
                    print("LLM generation failed:", e)
                    desc_text = simple
            else:
                low = col.lower()
                if low.endswith('_id') or low == 'id':
                    desc_text = 'Identifier linking to another entity.'
                elif 'date' in low or 'time' in low:
                    desc_text = 'Date or timestamp value.'
                elif any(x in low for x in ['name', 'title', 'desc', 'description']):
                    desc_text = 'Textual descriptive field.'
                elif any(x in low for x in ['qty', 'count', 'number', 'amount', 'price']):
                    desc_text = 'Numeric measure.'
                else:
                    desc_text = simple

            desc[t][col] = desc_text
    return desc


def detect_functional_dependencies(df: pd.DataFrame,
                                   max_det_size: int = 2,
                                   min_support: float = 1.0) -> List[Dict[str, Any]]:
    cols = list(df.columns)
    fds = []

    def _test_fd(det: List[str], dep: str) -> Tuple[bool, float]:
        sub = df[det + [dep]].dropna()
        if sub.empty:
            return False, 0.0
        grouped = sub.groupby(det)[dep].nunique()
        single = (grouped == 1).sum()
        total = len(grouped)
        support = single / max(total, 1)
        return (support >= min_support), support

    det_sets: List[List[str]] = [[c] for c in cols]
    if max_det_size >= 2:
        for i in range(len(cols)):
            for j in range(i + 1, len(cols)):
                det_sets.append([cols[i], cols[j]])

    for det in det_sets:
        det_low = [d.lower() for d in det]
        if any(x in d for d in det_low for x in ["qty", "quantity", "amount", "price", "total"]):
            continue
        for dep in cols:
            if dep in det:
                continue
            holds, support = _test_fd(det, dep)
            if holds:
                fds.append({"determinant": det, "dependent": dep, "holds": True, "support": support})
    return fds

# -----------------------------
# FD-based Decomposition
# -----------------------------
def propose_decomposition_for_table(df: pd.DataFrame,
                                    table_name: str,
                                    pk: Optional[str]) -> Dict[str, Any]:
    def _is_measure(col: str) -> bool:
        low = col.lower()
        return any(x in low for x in ["qty", "quantity", "amount", "price", "total", "cost", "rate"])

    def _is_identifier(col: str) -> bool:
        low = col.lower()
        return low == "id" or low.endswith("_id")

    fds = detect_functional_dependencies(df, max_det_size=1, min_support=1.0)
    dependents_by_det: Dict[Tuple[str, ...], Set[str]] = {}
    for fd in fds:
        det_tuple = tuple(fd["determinant"])
        dependents_by_det.setdefault(det_tuple, set()).add(fd["dependent"])

    if pk:
        dependents_by_det = {
            det: deps for det, deps in dependents_by_det.items()
            if not (len(det) == 1 and det[0] == pk)
        }

    dim_tables = []
    moved = {}

    def _det_table_name(det_cols: Tuple[str, ...]) -> str:
        if len(det_cols) == 1:
            base = det_cols[0]
            if base.endswith("_id"):
                return base[:-3] + "s"
            return f"{base}_dim"
        return "_".join(det_cols) + "_dim"

    for det, deps in dependents_by_det.items():
        det_cols = list(det)
        if not all(_is_identifier(d) for d in det_cols):
            continue
        if any(_is_measure(d) for d in det_cols):
            continue

        moved_deps = {dep for dep in deps if not _is_measure(dep)}
        if not moved_deps:
            continue

        dim_name = _det_table_name(det)
        dim_df = df[det_cols + sorted(list(moved_deps))].drop_duplicates()
        dim_pk = det_cols[0] if len(det_cols) == 1 else None

        dim_tables.append({
            "name": dim_name,
            "pk": dim_pk,
            "columns": {c: dim_df[c] for c in dim_df.columns},
            "source_det": det_cols
        })
        for dep in moved_deps:
            moved[dep] = dim_name

    base_cols = {c: df[c] for c in df.columns if c not in moved}
    base_fks = []
    for dim in dim_tables:
        for det_col in dim["source_det"]:
            if det_col in base_cols:
                base_fks.append({
                    "col": det_col,
                    "ref_table": dim["name"],
                    "ref_col": dim["pk"] or det_col
                })

    return {
        "base_table": {"name": table_name, "columns": base_cols, "pk": pk, "fks": base_fks},
        "dimension_tables": dim_tables,
        "moved": moved
    }


def decompose_tables_to_3nf(tables: Dict[str, pd.DataFrame], analysis: Dict[str, Any]) -> Dict[str, Any]:
    """
    Apply decomposition to each table using FDs, return a new LangGraph-style model dict.
    """
    pks = analysis.get('pks', {})
    types = analysis.get('types', {})
    descriptions = analysis.get('descriptions', {})

    model = {"tables": {}, "foreign_keys": [], "_meta": {"generated_by": "ModelLangGraph 3NF", "langgraph_compatible": True}}

    for tname, df in tables.items():
        pk = pks.get(tname)
        plan = propose_decomposition_for_table(df, tname, pk)

        # Base table
        base = plan["base_table"]
        model["tables"][base["name"]] = {
            "primary_key": base["pk"],
            "columns": {}
        }
        for col, series in base["columns"].items():
            model["tables"][base["name"]]["columns"][col] = {
                "type": types.get(tname, {}).get(col, infer_column_type(series)),
                "description": descriptions.get(tname, {}).get(col),
                "is_primary": (base["pk"] == col)
            }
        for fk in base["fks"]:
            model["foreign_keys"].append({
                "table": base["name"],
                "column": fk["col"],
                "ref_table": fk["ref_table"],
                "ref_column": fk["ref_col"]
            })

        # Dimension tables
        for dim in plan["dimension_tables"]:
            dname = dim["name"]
            model["tables"][dname] = {
                "primary_key": dim["pk"],
                "columns": {}
            }
            for col, series in dim["columns"].items():
                model["tables"][dname]["columns"][col] = {
                    "type": infer_column_type(series),
                    "description": descriptions.get(tname, {}).get(col),
                    "is_primary": (dim["pk"] == col)
                }

    return model


def _looks_like_id(col: str, series: pd.Series) -> bool:
    low = col.lower()
    if low == "id" or low.endswith("_id"):
        return True
    try:
        return pd.api.types.is_integer_dtype(series.dropna()) and (series.dropna().nunique() / max(1, len(series)) > 0.5)
    except Exception:
        return False


def save_langgraph_model_json(model: Dict, out_path: str):
    import json
    serializable_model = {}

    for name, obj in model.items():
        if isinstance(obj, pd.DataFrame):
            # Convert DataFrame to list of dicts
            serializable_model[name] = obj.to_dict(orient="records")
        elif isinstance(obj, dict):
            # Recursively handle nested dicts
            serializable_model[name] = {}
            for k, v in obj.items():
                if isinstance(v, pd.DataFrame):
                    serializable_model[name][k] = v.to_dict(orient="records")
                else:
                    serializable_model[name][k] = v
        else:
            serializable_model[name] = obj

    with open(out_path, "w", encoding="utf8") as fh:
        json.dump(serializable_model, fh, indent=2)

def generate_sql_schema(model: Dict[str, Any]) -> str:
    """
    Generate SQL CREATE TABLE statements with PKs and FKs from the normalized model.
    """
    sql_statements = []
    for tname, tinfo in model.get("tables", {}).items():
        cols_sql = []
        pk = tinfo.get("primary_key")
        for col, meta in tinfo["columns"].items():
            col_type = meta.get("type", "TEXT")
            cols_sql.append(f"    {col} {col_type}")
        if pk:
            cols_sql.append(f"    PRIMARY KEY ({pk})")
        stmt = f"CREATE TABLE {tname} (\n" + ",\n".join(cols_sql) + "\n);"
        sql_statements.append(stmt)

    # Foreign keys
    for fk in model.get("foreign_keys", []):
        stmt = f"ALTER TABLE {fk['table']} ADD FOREIGN KEY ({fk['column']}) " \
               f"REFERENCES {fk['ref_table']}({fk['ref_column']});"
        sql_statements.append(stmt)

    return "\n\n".join(sql_statements)


def generate_catalog_json(model: Dict[str, Any]) -> Dict[str, Any]:
    """
    Generate a compact catalog JSON summarizing tables, columns, PKs, and FKs.
    """
    catalog = {"tables": {}, "foreign_keys": []}
    for tname, tinfo in model.get("tables", {}).items():
        catalog["tables"][tname] = {
            "primary_key": tinfo.get("primary_key"),
            "columns": list(tinfo["columns"].keys())
        }
    for fk in model.get("foreign_keys", []):
        catalog["foreign_keys"].append(fk)
    return catalog


def generate_erd_dot(model: Dict[str, Any]) -> str:
    """
    Generate a Graphviz DOT representation of the ERD.
    """
    lines = ["digraph ERD {", "  rankdir=LR;"]
    # Nodes
    for tname, tinfo in model.get("tables", {}).items():
        cols = "\\n".join([f"{c}" for c in tinfo["columns"].keys()])
        lines.append(f'  {tname} [shape=record, label="{{{tname}|{cols}}}"];')
    # Edges
    for fk in model.get("foreign_keys", []):
        lines.append(f'  {fk["table"]} -> {fk["ref_table"]} [label="{fk["column"]}"];')
    lines.append("}")
    return "\n".join(lines)



# -----------------------------
# Extended Normalizer Integration
# -----------------------------
from model_langgraph.normalizer import Normalizer3NF

def analyze_and_normalize(tables: Dict[str, pd.DataFrame]) -> Dict[str, Any]:
    """
    Extended analysis: run PK/FK detection, FD decomposition,
    and Normalizer3NF merging logic for multi-source handling.
    """
    # Step 1: basic profiling
    analysis = {
        "pks": detect_primary_keys(tables),
        "fks": detect_foreign_keys(tables, detect_primary_keys(tables)),
        "descriptions": generate_column_descriptions(tables),
        "types": {t: {c: infer_column_type(df[c]) for c in df.columns} for t, df in tables.items()}
    }

    # Step 2: FD-based decomposition
    model_fd = decompose_tables_to_3nf(tables, analysis)

    # Step 3: Normalizer3NF for multi-source merging
    norm = Normalizer3NF()
    for name, df in tables.items():
        norm.normalize_and_merge(name, df)
    model_norm = norm.model

    return {
        "fd_model": model_fd,
        "normalized_model": model_norm,
        "analysis": analysis
    }

def convert_normalized_to_model(norm_model: Dict[str, pd.DataFrame]) -> Dict[str, Any]:
    model = {"tables": {}, "foreign_keys": []}
    for tname, df in norm_model.items():
        model["tables"][tname] = {
            "primary_key": None,  # or detect from columns
            "columns": {col: {"type": infer_column_type(df[col]),
                              "description": None,
                              "is_primary": False}
                        for col in df.columns}
        }
    return model
from model_langgraph.fd_discovery import tane_fd_discovery, minimal_cover, bernstein_synthesis, materialize_relations

def analyze_and_normalize_generic(df: pd.DataFrame, tolerance: float = 0.0) -> Dict[str, Any]:
    """
    Run domain-agnostic FD discovery and 3NF synthesis on any denormalized DataFrame.
    """
    fds = tane_fd_discovery(df, support_tolerance=tolerance)
    min_cov = minimal_cover(fds)
    relations = bernstein_synthesis(min_cov)
    frames = materialize_relations(df, relations)

    normalized_model = {f["name"]: f["df"] for f in frames}
    return {
        "normalized_model": normalized_model,
        "relations": relations,
        "fds": min_cov
    }



# Backward-compatible wrapper for CLI
def analyze(tables: Dict[str, pd.DataFrame]) -> Dict[str, Any]:
    """
    Wrapper so CLI can still call `analyze`.
    Returns the normalized model by default.
    """
    result = analyze_and_normalize(tables)
    return result["normalized_model"]
