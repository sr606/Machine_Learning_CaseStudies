import argparse
import os
import pandas as pd
from model_langgraph.loader import load_csv_folder, load_json_file
from model_langgraph.analyzer import analyze_and_normalize, save_langgraph_model_json, \
    generate_sql_schema, generate_catalog_json, generate_erd_dot, convert_normalized_to_model
from model_langgraph.fd_discovery import analyze_and_normalize_generic, detect_primary_keys, \
    infer_foreign_keys, generate_sql, generate_erd

def main():
    parser = argparse.ArgumentParser(description="3NF Data Modeling CLI")
    parser.add_argument("input", help="Input folder (CSV files) or JSON file")
    parser.add_argument("--out-model", help="Output JSON file for normalized model")
    parser.add_argument("--out-sql", help="Output SQL schema file")
    parser.add_argument("--out-catalog", help="Output catalog JSON file")
    parser.add_argument("--out-dot", help="Output ERD dot file")
    parser.add_argument("--generic-3nf", action="store_true", help="Use domain-agnostic FD-based normalization")
    parser.add_argument("--tolerance", type=float, default=0.0, help="FD tolerance (e.g. 0.05 allows 5% violations)")

    args = parser.parse_args()

    # Load input data
    if os.path.isdir(args.input):
        tables = load_csv_folder(args.input)
    else:
        tables = load_json_file(args.input)

    # 🔹 Generic FD-based 3NF synthesis
    if args.generic_3nf:
        # Flatten all tables into one DataFrame
        df = pd.concat(tables.values(), axis=0, ignore_index=True)

        result = analyze_and_normalize_generic(df, tolerance=args.tolerance)
        normalized_model = result["normalized_model"]

        # Save normalized CSVs
        out_dir = os.path.dirname(args.out_model or args.out_sql or args.out_dot or ".")
        for name, table in normalized_model.items():
            table.to_csv(os.path.join(out_dir, f"{name}.csv"), index=False)

        # Generate SQL and ERD
        frames = [{"name": k, "df": v, "attrs": list(v.columns), "key": [], "pk": []} for k, v in normalized_model.items()]
        detect_primary_keys(frames)
        fks = infer_foreign_keys(frames)

        if args.out_sql:
            sql_text = generate_sql(frames, fks)
            with open(args.out_sql, "w", encoding="utf-8") as f:
                f.write(sql_text)

        if args.out_dot:
            dot_text = generate_erd(frames, fks)
            with open(args.out_dot, "w", encoding="utf-8") as f:
                f.write(dot_text)

        print("✅ Generic 3NF synthesis complete.")
        if args.out_sql: print(" - SQL schema:", args.out_sql)
        if args.out_dot: print(" - ERD dot file:", args.out_dot)
        return

    # 🔹 Domain-specific pipeline
    result = analyze_and_normalize(tables)
    norm_model = convert_normalized_to_model(result["normalized_model"])

    if args.out_model:
        save_langgraph_model_json(norm_model, args.out_model)

    if args.out_sql:
        sql_text = generate_sql_schema(norm_model)
        with open(args.out_sql, "w", encoding="utf8") as f:
            f.write(sql_text)

    if args.out_catalog:
        catalog = generate_catalog_json(norm_model)
        save_langgraph_model_json(catalog, args.out_catalog)

    if args.out_dot:
        dot_text = generate_erd_dot(norm_model)
        with open(args.out_dot, "w", encoding="utf8") as f:
            f.write(dot_text)

    print("✅ 3NF normalization complete.")
    if args.out_model: print(" - Normalized model:", args.out_model)
    if args.out_sql: print(" - SQL schema:", args.out_sql)
    if args.out_catalog: print(" - Catalog JSON:", args.out_catalog)
    if args.out_dot: print(" - ERD dot file:", args.out_dot)

if __name__ == "__main__":
    main()
