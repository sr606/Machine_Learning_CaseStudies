import os
import json
import random
import argparse
from datetime import datetime, timedelta
import numpy as np
import pandas as pd
from faker import Faker

random.seed(42)
np.random.seed(42)

def daterange(days):
    end = datetime.now()
    start = end - timedelta(days=days)
    return start, end

def random_ts(start, end):
    delta = end - start
    return start + timedelta(seconds=random.randint(0, int(delta.total_seconds())))

def bounce_prob(hour):
    # Higher activity evenings; lower overnight
    return 0.15 + 0.25 * (0.5 + 0.5 * np.sin((hour - 12) / 24 * 2 * np.pi))

def currency_for_country(country):
    return {"India": "INR", "United States": "USD", "United Kingdom": "GBP",
            "Germany": "EUR", "Japan": "JPY"}.get(country, "USD")

def gen_customers(fake, n):
    countries = ["India", "United States", "United Kingdom", "Germany", "Japan", "Singapore", "Australia", "Canada", "UAE"]
    rows = []
    for i in range(1, n+1):
        country = random.choice(countries)
        city = fake.city()
        state = fake.state()
        signup = fake.date_time_between(start_date="-365d", end_date="now")
        rows.append({
            "customer_id": i,
            "first_name": fake.first_name(),
            "last_name": fake.last_name(),
            "email": fake.unique.email(),
            "phone": fake.phone_number(),
            "city": city,
            "state": state,
            "country": country,
            "signup_date": signup.isoformat(),
            "marketing_opt_in": random.random() < 0.6
        })
    return pd.DataFrame(rows)

def gen_products(fake, n):
    categories = ["Electronics", "Apparel", "Home", "Beauty", "Sports", "Books", "Grocery", "Toys", "Automotive"]
    brands = ["Acme", "Globex", "Initech", "Umbrella", "Soylent", "Stark", "Wayne", "Hooli", "Wonka", "Nakatomi"]
    rows = []
    for i in range(1, n+1):
        cat = random.choice(categories)
        brand = random.choice(brands)
        price = round(np.clip(np.random.lognormal(mean=3, sigma=0.6), 5, 5000), 2)
        cost = round(price * random.uniform(0.4, 0.8), 2)
        created_at = fake.date_time_between(start_date="-120d", end_date="now")
        attrs = {
            "color": random.choice(["red","blue","black","white","green","silver","gold"]),
            "size": random.choice(["XS","S","M","L","XL","NA"]),
            "material": random.choice(["cotton","polyester","leather","metal","plastic","wood"]),
            "warranty_months": random.choice([0,6,12,24]),
        }
        rows.append({
            "product_id": i,
            "name": f"{brand} {cat} {fake.word()}",
            "category": cat,
            "brand": brand,
            "price": price,
            "cost": cost,
            "currency": "USD",
            "attributes": json.dumps(attrs),
            "created_at": created_at.isoformat()
        })
    return pd.DataFrame(rows)

def gen_sessions(customers_df, n_sessions, start, end):
    devices = ["mobile", "desktop", "tablet"]
    referrers = ["direct","seo","email","social","paid"]
    utm_sources = ["google","facebook","instagram","twitter","newsletter","referral"]
    rows = []
    for i in range(1, n_sessions+1):
        cust = int(customers_df.sample(1)["customer_id"].iloc[0])
        st = random_ts(start, end)
        duration = timedelta(minutes=random.randint(1, 60))
        en = st + duration
        rows.append({
            "session_id": i,
            "customer_id": cust,
            "started_at": st.isoformat(),
            "ended_at": en.isoformat(),
            "device": random.choice(devices),
            "geo_country": customers_df.loc[customers_df["customer_id"]==cust, "country"].iloc[0],
            "referrer": random.choice(referrers),
            "utm_source": random.choice(utm_sources),
            "utm_campaign": random.choice(["summer_sale","diwali_blast","bf_cm","new_launch","clearance"]),
            "utm_medium": random.choice(["cpc","cpm","organic","email","social"])
        })
    return pd.DataFrame(rows)

def gen_orders(customers_df, n_orders, start, end):
    statuses = ["pending","paid","shipped","delivered","cancelled","refunded"]
    payments = ["card","upi","netbanking","cod","wallet","paypal"]
    rows = []
    for i in range(1, n_orders+1):
        cust = int(customers_df.sample(1)["customer_id"].iloc[0])
        ts = random_ts(start, end)
        country = customers_df.loc[customers_df["customer_id"]==cust, "country"].iloc[0]
        currency = currency_for_country(country)
        subtotal = round(np.clip(np.random.lognormal(4, 0.5), 10, 10000), 2)
        shipping = round(random.choice([0, 49, 99, 149]), 2)
        tax = round(subtotal * random.uniform(0.05, 0.18), 2)
        total = round(subtotal + shipping + tax, 2)
        rows.append({
            "order_id": i,
            "customer_id": cust,
            "order_date": ts.isoformat(),
            "status": np.random.choice(statuses, p=[0.05,0.45,0.15,0.25,0.07,0.03]),
            "payment_method": np.random.choice(payments, p=[0.5,0.2,0.1,0.1,0.05,0.05]),
            "subtotal": subtotal,
            "tax": tax,
            "shipping": shipping,
            "total": total,
            "currency": currency,
            "ship_city": customers_df.loc[customers_df["customer_id"]==cust, "city"].iloc[0],
            "ship_state": customers_df.loc[customers_df["customer_id"]==cust, "state"].iloc[0],
            "ship_country": country
        })
    return pd.DataFrame(rows)

def gen_order_items(orders_df, products_df):
    rows = []
    for _, od in orders_df.iterrows():
        n_items = np.random.choice([1,2,3,4,5], p=[0.45,0.25,0.15,0.1,0.05])
        prods = products_df.sample(n_items)
        for _, pr in prods.iterrows():
            qty = np.random.choice([1,2,3,4], p=[0.6,0.25,0.1,0.05])
            unit = float(pr["price"]) * np.random.uniform(0.8, 1.0)  # discounts
            disc = round(np.random.choice([0,5,10,15,20], p=[0.6,0.15,0.1,0.1,0.05]), 2)
            line_total = round(qty * unit * (1 - disc/100.0), 2)
            rows.append({
                "order_id": int(od["order_id"]),
                "product_id": int(pr["product_id"]),
                "quantity": int(qty),
                "unit_price": round(unit, 2),
                "discount_pct": disc,
                "line_total": line_total
            })
    return pd.DataFrame(rows)

def gen_inventory_snapshots(products_df, days):
    start, end = daterange(days)
    all_rows = []
    date_list = [start + timedelta(days=i) for i in range(days)]
    for _, pr in products_df.iterrows():
        stock = np.random.randint(20, 500)
        safety = int(stock * 0.1)
        for dt in date_list:
            # random daily change
            stock = max(0, stock + np.random.randint(-10, 10))
            all_rows.append({
                "product_id": int(pr["product_id"]),
                "snapshot_date": dt.date().isoformat(),
                "stock": int(stock),
                "safety_stock": int(safety)
            })
    return pd.DataFrame(all_rows)

def gen_events_jsonl(sessions_df, products_df, out_path, multiplier=5):
    types = ["page_view","search","add_to_cart","wishlist","purchase","logout"]
    ab_tests = ["A","B","control"]
    with open(os.path.join(out_path, "events.jsonl"), "w", encoding="utf-8") as fh:
        for _, s in sessions_df.iterrows():
            n = np.random.randint(3, 3+multiplier)
            base_ts = datetime.fromisoformat(s["started_at"])
            for k in range(n):
                ts = base_ts + timedelta(seconds=np.random.randint(5, 900))
                etype = np.random.choice(types, p=[0.45,0.1,0.2,0.08,0.05,0.12])
                event = {
                    "event_id": f"ev_{s['session_id']}_{k}",
                    "session_id": int(s["session_id"]),
                    "customer_id": int(s["customer_id"]),
                    "ts": ts.isoformat(),
                    "type": etype,
                    "context": {
                        "device": s["device"],
                        "geo": {"country": s["geo_country"]},
                        "app_version": f"1.{np.random.randint(0,9)}.{np.random.randint(0,9)}",
                        "ab_test": np.random.choice(ab_tests)
                    },
                    "page": {
                        "route": np.random.choice(["/","/p","/cart","/checkout","/search","/account"]),
                        "query_params": {"q": np.random.choice(["phone","shirt","book","tv","shoes","bag","na"])},
                        "experiment": np.random.choice(["new_nav","sticky_cta","ctrl"])
                    }
                }
                if etype in ["add_to_cart","purchase","wishlist"]:
                    picks = products_df.sample(np.random.randint(1, 4))
                    items = []
                    cart_value = 0.0
                    for _, pr in picks.iterrows():
                        qty = np.random.randint(1, 3)
                        price = float(pr["price"])
                        items.append({"product_id": int(pr["product_id"]), "qty": qty, "price": price})
                        cart_value += qty * price
                    event["cart"] = {"items": items, "cart_value": round(cart_value,2)}
                if etype == "purchase":
                    event["payment"] = {"status": np.random.choice(["success","failed"], p=[0.92,0.08]),
                                        "method": np.random.choice(["card","upi","wallet","netbanking","paypal"])}
                fh.write(json.dumps(event) + "\n")

def gen_nested_customers_json(customers_df, out_path):
    data = []
    for _, r in customers_df.iterrows():
        data.append({
            "customer_id": int(r["customer_id"]),
            "name": {"first": r["first_name"], "last": r["last_name"]},
            "contact": {"email": r["email"], "phone": r["phone"]},
            "address": {"city": r["city"], "state": r["state"], "country": r["country"]},
            "preferences": {"marketing_opt_in": bool(r["marketing_opt_in"]), "language": random.choice(["en","hi","de","ja"])}
        })
    with open(os.path.join(out_path, "customers_nested.json"), "w", encoding="utf-8") as fh:
        json.dump(data, fh, indent=2)

def gen_nested_orders_json(orders_df, order_items_df, out_path):
    groups = order_items_df.groupby("order_id")
    data = []
    for _, od in orders_df.iterrows():
        items = []
        if int(od["order_id"]) in groups.indices:
            items_df = order_items_df.loc[groups.indices[int(od["order_id"])]]
            for _, it in items_df.iterrows():
                items.append({
                    "product_id": int(it["product_id"]),
                    "quantity": int(it["quantity"]),
                    "unit_price": float(it["unit_price"]),
                    "discount_pct": float(it["discount_pct"]),
                    "line_total": float(it["line_total"])
                })
        data.append({
            "order_id": int(od["order_id"]),
            "customer_id": int(od["customer_id"]),
            "status": od["status"],
            "order_date": od["order_date"],
            "currency": od["currency"],
            "totals": {"subtotal": float(od["subtotal"]), "tax": float(od["tax"]), "shipping": float(od["shipping"]), "total": float(od["total"])},
            "shipping": {"city": od["ship_city"], "state": od["ship_state"], "country": od["ship_country"]},
            "items": items
        })
    with open(os.path.join(out_path, "orders_nested.json"), "w", encoding="utf-8") as fh:
        json.dump(data, fh, indent=2)

def main():
    parser = argparse.ArgumentParser(description="Generate synthetic e-commerce dataset (CSV + JSON/JSONL)")
    parser.add_argument("--out", required=True, help="Output folder")
    parser.add_argument("--days", type=int, default=90, help="Number of days for time series/events")
    parser.add_argument("--customers", type=int, default=15000)
    parser.add_argument("--products", type=int, default=3000)
    parser.add_argument("--orders", type=int, default=25000)
    parser.add_argument("--sessions", type=int, default=40000)
    args = parser.parse_args()

    os.makedirs(args.out, exist_ok=True)
    fake = Faker()
    start, end = daterange(args.days)

    print("Generating customers...")
    customers = gen_customers(fake, args.customers)
    customers.to_csv(os.path.join(args.out, "customers.csv"), index=False)

    print("Generating products...")
    products = gen_products(fake, args.products)
    products.to_csv(os.path.join(args.out, "products.csv"), index=False)

    print("Generating orders...")
    orders = gen_orders(customers, args.orders, start, end)
    orders.to_csv(os.path.join(args.out, "orders.csv"), index=False)

    print("Generating order_items...")
    order_items = gen_order_items(orders, products)
    order_items.to_csv(os.path.join(args.out, "order_items.csv"), index=False)

    print("Generating inventory snapshots (time series)...")
    inventory = gen_inventory_snapshots(products, args.days)
    inventory.to_csv(os.path.join(args.out, "inventory_snapshots.csv"), index=False)

    print("Generating sessions...")
    sessions = gen_sessions(customers, args.sessions, start, end)
    sessions.to_csv(os.path.join(args.out, "sessions.csv"), index=False)

    print("Generating events.jsonl (nested logs)...")
    gen_events_jsonl(sessions, products, args.out, multiplier=5)

    print("Generating nested customers.json ...")
    gen_nested_customers_json(customers, args.out)

    print("Generating nested orders.json ...")
    gen_nested_orders_json(orders, order_items, args.out)

    print("Done. Files written to:", args.out)

if __name__ == "__main__":
    main()
