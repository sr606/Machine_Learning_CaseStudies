import pandas as pd

class Normalizer3NF:
    def __init__(self):
        self.model = {}

    def normalize_table(self, table_name: str, df: pd.DataFrame):
        normalized = {}
        pk = None

        # Detect PK
        for col in df.columns:
            if col.lower().endswith("_id") or col.lower() == "id":
                pk = col
                break
        if pk is None:
            pk = f"{table_name}_id"
            df[pk] = range(1, len(df) + 1)

        # Contacts
        for col in df.columns:
            if any(x in col.lower() for x in ["phone", "email", "website"]):
                contacts = df[[pk, col]].dropna()
                normalized[f"{table_name}_contacts"] = contacts

        # Measures
        measure_cols = [c for c in df.columns if any(x in c.lower() for x in ["score", "price", "quantity"])]
        if measure_cols:
            measures = df[[pk] + measure_cols].dropna()
            normalized[f"{table_name}_measures"] = measures

        # Base table
        base_cols = [c for c in df.columns if c not in measure_cols and not any(x in c.lower() for x in ["phone", "email", "website"])]
        normalized[f"{table_name}_base"] = df[base_cols]

        return normalized

    def merge_with_existing_model(self, new_tables: dict):
        for name, df in new_tables.items():
            if name in self.model:
                self.model[name] = pd.concat([self.model[name], df]).drop_duplicates()
            else:
                self.model[name] = df

        # Detect relationships
        for n1, df1 in new_tables.items():
            for n2, df2 in self.model.items():
                if n1 == n2:
                    continue
                common_ids = set(df1.columns).intersection(set(df2.columns))
                for cid in common_ids:
                    if cid.endswith("_id"):
                        print(f"Relationship detected: {n1}.{cid} → {n2}.{cid}")

    def normalize_and_merge(self, table_name: str, df: pd.DataFrame):
        new_tables = self.normalize_table(table_name, df)
        self.merge_with_existing_model(new_tables)
        return self.model
